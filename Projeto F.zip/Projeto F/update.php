<?php 
$id = $_GET['id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

<!-- Google Web Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">

<!-- Icon Font Stylesheet -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

<!-- Libraries Stylesheet -->
<link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

<!-- Customized Bootstrap Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet">

<!-- Template Stylesheet -->
<link href="css/style.css" rel="stylesheet">
</head>
<body>
<form method="post" class="p-5">
<div class="my-3">
    <label class="form-label" for="nome">Nome da loja</label>
    <input class="form-control" type="text" name="nome" value="<?php echo $dados->Nome_da_loja; ?>">
</div>
<div class="my-3">
    <label class="form-label" for="proprietario"> Proprietario</label>
    <input class="form-control" type="text" name="proprietario" value="<?php echo $dados->Proprietario; ?>">
</div>
<div class="my-3">
    <label class="form-label" for="localizacao"> Localização</label>
    <input class="form-control" type="text" name="localizacao" value="<?php echo $dados->Localizacao; ?>">
</div>


<div class="my-3">
    <input class="btn btn-primary" type="submit" name="save" value="Atualizar">
</div>

</form>

<?php 
require 'connect.php';
if (isset($_POST['save'])) {
    $cmd = $conn->prepare('UPDATE Registro SET Nome_da_loja = :nome,Proprietario = :proprietario, Localizacao = :localizacao WHERE Id_loja = :id');
    $cmd->bindValue(':nome', $_POST['nome']);
    $cmd->bindValue(':proprietario', $_POST['proprietario']);
    $cmd->bindValue(':localizacao', $_POST['localizacao']);
    $cmd->bindValue(':id', $id);
    $cmd->execute();
    
    header('location:lista.php');

    
}
?>



</body>
</html>