<?php
try{
    $conn = new PDO("mysql:host=localhost;dbname=projeto_f",'root',"");
    $conn ->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    //echo"Conectado com sucesso!"
}catch(PDOException $e){
    echo "Erro de Coneccao: ".$e->getMessage();
}
?>