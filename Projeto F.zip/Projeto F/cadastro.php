<?php

require_once 'usuarios.php';
$u = new Usuario;
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div id="corpo-cad">
    <h1>Cadastrar</h1>
<form method="post" >
    <input type="text" name="nome" placeholder="Nome Completo" maxlength="30">
    <input type="text" name="telefone" placeholder="Telefone" maxlength="30">
    <input type="email" name="email" placeholder="Email" maxlength="40">
    <input type="password" name="senha" placeholder="Senha" maxlength="15">
    <input type="password" name="confSenha" placeholder="Confirmar Senha" maxlength="15">
    <input type="submit" value="Cadastrar">
</form>
</div>
<?php

    if(isset($_POST['nome'])){
        $nome=addslashes($_POST['nome']);
        $telefone = addslashes($_POST['telefone']);
        $email =addslashes($_POST['email']);
        $senha =addslashes($_POST['senha']);
        $confirmarSenha = addslashes($_POST['confSenha']);
        //verificar se o campo foi preenchido
        if(!empty($nome) && !empty($telefone) && !empty($email) && !empty($senha) && !empty($confirmarSenha)){

            $u->conectar("projeto_f","localhost","root", "");
            if($u-> msgErro == "") //tudo certo
            {
                if($senha == $confirmarSenha){
                if($u->cadastrar($nome,$telefone,$email,$senha)){
                    ?>
                    <div id="msg-sucess">
                    Cadastrado com sucesso! Faça login para entrar.
                    </div>

                    <?php
                }else{
                    ?>
                    <div class="msg-erro">
                    Email ja cadastrado!
                    </div>
                    
                    <?php
                }
                }else{
                    ?>
                    <div class="msg-erro">
                    Introduziu Senhas Diferentes, Tente novamente.
                    </div>
                    
                    <?php
                }
            }else{
                ?>
                <div class="msg-erro">
                <?php echo 'Erro'.$u->msgErro;?>
                </div>
                <?php
                
            
            }
        }else{
            ?>
            <div class="msg-erro">
            Preencha todos os campos!
            </div>

            <?php
        }
    }
?>
    
</body>
</html>