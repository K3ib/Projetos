<?php

require_once 'usuarios.php';
$u = new Usuario;
session_start();
    session_unset();
    session_destroy();

    header("location: login.php");
?>